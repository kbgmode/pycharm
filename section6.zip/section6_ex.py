def calcul1(p1, p2):
    print('>> calcul1')
    return 2 + p1 * p2


def calcul2(p1, p2):
    print('>> calcul2')
    return 3 + p1 * p2
